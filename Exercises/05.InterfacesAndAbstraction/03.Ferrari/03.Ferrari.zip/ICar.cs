﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferrari
{
    public interface ICar
    {
        string Brakes();

        string Gas();
    }
}
