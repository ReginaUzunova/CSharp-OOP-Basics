﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _07.SpeedRacing
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Car> cars = new List<Car>();
            Car car = new Car();

            int n = int.Parse(Console.ReadLine());
            double fuelConsumption = 0.0;
            double fuelAmount = 0.0;

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();

                string carModel = input[0];
                fuelAmount = double.Parse(input[1]);
                fuelConsumption = double.Parse(input[2]);


                car = new Car(carModel, fuelAmount, fuelConsumption);

                cars.Add(car);
            }

            string[] command = Console.ReadLine().Split();
            int amountOfKm = 0;
            string carToDrive = "";

            while (command[0] != "End")
            {
                carToDrive = command[1];
                amountOfKm = int.Parse(command[2]);

                Car currentCar = cars.Where(c => c.Model == carToDrive).FirstOrDefault();

                currentCar.CalculateMove(amountOfKm);

                command = Console.ReadLine().Split();
            }

            foreach (var item in cars)
            {
                Console.WriteLine($"{item.Model} {item.FuelAmount:F2} {item.TraveledDistance}");
            }
        }
    }
}
