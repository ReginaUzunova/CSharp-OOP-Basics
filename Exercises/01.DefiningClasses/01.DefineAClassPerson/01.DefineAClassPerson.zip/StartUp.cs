﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person = new Person("Pesho", 20);
            Person secondPerson = new Person("Gosho", 18);
            Person thirdPerson = new Person("Stamat", 43);

            
        }
    }
}
